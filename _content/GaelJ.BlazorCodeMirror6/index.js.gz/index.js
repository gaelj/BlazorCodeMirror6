export { K as clearLocalStorage, M as dispatchCommand, O as dispose, J as forceRedraw, D as getAllSupportedLanguageNames, w as getCmInstance, A as initCodeMirror, B as maxDocLengthLintSource, z as onDispose, y as onUpdate, x as requestLinterRefresh, F as setConfiguration, H as setCssCompletions, G as setMentionCompletions } from './index-CNje1ZrY.js';
//# sourceMappingURL=index.js.map
