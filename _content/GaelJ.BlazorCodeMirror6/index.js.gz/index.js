export { J as clearLocalStorage, K as dispatchCommand, M as dispose, H as forceRedraw, D as getAllSupportedLanguageNames, w as getCmInstance, A as initCodeMirror, B as maxDocLengthLintSource, z as onDispose, y as onUpdate, x as requestLinterRefresh, F as setConfiguration, G as setMentionCompletions } from './index-Bb0AfIBE.js';
//# sourceMappingURL=index.js.map
